//
//  MapView.swift
//  TripVisaApp
//
//  Created by Yuvika Pabba on 4/20/25.
//


import SwiftUI
import MapKit

struct MapView: View {
    @State private var region = MKCoordinateRegion(
        center: CLLocationCoordinate2D(latitude: 37.7749, longitude: -122.4194),
        span: MKCoordinateSpan(latitudeDelta: 0.1, longitudeDelta: 0.1)
    )
    @State private var annotations: [PlaceAnnotation] = []

    var body: some View {
        Map(coordinateRegion: $region, annotationItems: annotations) { place in
            MapMarker(coordinate: place.coordinate, tint: .blue)
        }
        .onAppear {
            loadPlaces()
        }
        .navigationTitle("Map")
        .ignoresSafeArea(edges: .bottom)
    }

    func loadPlaces() {
        // Replace with real data loading
        let sample = PlaceAnnotation(
            id: UUID(),
            name: "Sample Place",
            coordinate: CLLocationCoordinate2D(latitude: 37.7749, longitude: -122.4194)
        )
        annotations = [sample]
    }
}

struct PlaceAnnotation: Identifiable {
    let id: UUID
    let name: String
    let coordinate: CLLocationCoordinate2D
}